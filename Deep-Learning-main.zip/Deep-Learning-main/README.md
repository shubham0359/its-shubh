# Deep-Learning
Lab practicals from the Deep Learning course at my institution. Covers important topics like Logistic Regression, Cost and Loss Function, development of CNNs and more.\
HR folder - Logistic Regression\
Insurance folder - Cost & Loss Function, Gradient Descent & Regularization\
Potato Disease folder - CNN model to predict Potato Disease
